package com.jeanlima.mvcappdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcAppDatajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
