package com.jeanlima.springrestapi.service;

public interface PedidoService {
}
