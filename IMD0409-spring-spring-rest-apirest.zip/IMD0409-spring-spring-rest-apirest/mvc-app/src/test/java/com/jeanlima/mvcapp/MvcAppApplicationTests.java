package com.jeanlima.mvcapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
